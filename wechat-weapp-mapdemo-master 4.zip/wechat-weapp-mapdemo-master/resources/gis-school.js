module.exports=[
    {
        "id": 1,
    "name": "夸克链信建昌运营中心",
        "longitude": "119.814880",
        "latitude": "40.815701"
    },
    {
        "id": 2,
      "name": "惠州市惠城区城市节点",
      "longitude": "114.450849",
      "latitude": "23.095701"
    },
    {
        "id": 3,
      "name": "青岛市崂山区节点",
      "longitude": "120.387610",
      "latitude": "36.098500"
    },
    {
        "id": 4,
      "name": "巴音郭楞蒙古自治州库尔勒市节点",
      "longitude": "86.161262076",
      "latitude": "41.7450883324"
    },
    {
        "id": 5,
      "name": "南昌市南昌县节点",
      "longitude": "116.019936",
      "latitude": "28.674316"
    },
    {
        "id": 6,
      "name": "重庆主城区节点",
      "longitude": "106.571953",
      "latitude": "29.521376"
    },
    {
        "id": 7,
      "name": "运城市盐湖区城市节点",
      "longitude": "111.039124",
      "latitude": "35.083710"
    },
    {
        "id": 8,
      "name": "怀化市鹤城区节点",
      "longitude": "110.016525",
      "latitude": "27.583958"
    },
    {
        "id": 9,
      "name": "链信株洲运营中心",
      "longitude": "113.159473",
      "latitude": "27.854492"
    },
    {
        "id": 10,
      "name": "天津市津南区节点",
      "longitude": "117.214836",
      "latitude": "39.185822"
    },
    {
        "id": 11,
      "name": "重庆市永川区节点",
      "longitude": "105.896550",
      "latitude": "29.348780"
    },
    {
        "id": 12,
      "name": "徐州市云龙区节点",
      "longitude": "117.244202",
      "latitude": "34.253689"
    },
    {
        "id": 13,
      "name": "咸宁市咸安区节点",
      "longitude": "114.333875",
      "latitude": "29.841584"
    },
    {
        "id": 14,
      "name": "链信随州城市节点运营中心",
      "longitude": "113.369649",
      "latitude": "31.704770"
    },
    {
        "id": 15,
      "name": "连云港市节点",
      "longitude": "118.792006",
      "latitude": "34.544647"
    },
    {
        "id": 16,
      "name": "廊坊市三河城市节点",
      "longitude": "116.483115",
      "latitude": "39.574808"
    },
    {
        "id": 17,
      "name": "大连城市节点",
      "longitude": "121.593323",
      "latitude": "38.991592"
    },
    {
        "id": 18,
      "name": "苏州市节点",
      "longitude": "120.581804",
      "latitude": "31.299499"
    },
    {
        "id": 19,
      "name": "链信合肥运营中心",
      "longitude": "117.233760",
      "latitude": "31.853681"
    },
    {
        "id": 20,
      "name": "淄博市张店区节点",
      "longitude": "118.017993",
      "latitude": "36.806287"
    },
    {
        "id": 21,
      "name": "临沂市河东区节点",
      "longitude": "118.407926",
      "latitude": "35.021581"
    },
    {
        "id": 22,
      "name": "太原链信节点",
      "longitude": "112.323737",
      "latitude": "37.521248"
    },
    {
        "id": 23,
      "name": "铁岭市调兵山节点",
      "longitude": "123.567006",
      "latitude": "42.467828"
    },
    {
        "id": 24,
      "name": "阜阳市颍东区节点",
      "longitude": "115.512269",
      "latitude": "32.535922"
    },
    {
        "id": 25,
      "name": "武汉市节点",
      "longitude": "114.428028",
      "latitude": "30.47767"
    },
    {
        "id": 26,
      "name": "新乡市节点",
      "longitude": "113.924927",
      "latitude": "35.296928"
    },
    {
        "id": 27,
      "name": "郑州城市节点",
      "longitude": "113.685755",
      "latitude": "34.795464"
    },
    {
        "id": 28,
      "name": "洛阳城市节点",
      "longitude": "112.2399768",
      "latitude": "34.665288"
    },
    {
        "id": 29,
      "name": "沈阳市城市节点",
      "longitude": "123.402187",
      "latitude": "41.897618"
    },
    {
        "id": 30,
      "name": "绍兴运营中心",
      "longitude": "120.5115694",
      "latitude": "30.1068879"
    },
    {
        "id": 31,
      "name": "浦城夸克链信运营中心",
      "longitude": "118.517918",
      "latitude": "27.920365"
    },
    {
        "id": 32,
      "name": "北京市朝阳区节点",
      "longitude": "116.5101966278",
      "latitude": "40.0111958036"
    },
    {
        "id": 33,
      "name": "北京市丰台区节点",
      "longitude": "116.5101966278",
      "latitude": "40.0111958036"
    },
    {
        "id": 34,
      "name": "南宁市西乡塘区节点",
      "longitude": "108.298722",
      "latitude": "22.875183"
    },
    {
        "id": 35,
      "name": "厦门市集美区节点",
      "longitude": "118.053389",
      "latitude": "24.571547"
    },
    {
        "id": 36,
      "name": "洛阳市伊川县节点",
      "longitude": "112.421181",
      "latitude": "34.431601"
    },
    {
        "id": 37,
      "name": "夸克链信深圳运营中心",
      "longitude": "113.555071",
      "latitude": "22.311730"
    },
    {
        "id": 38,
      "name": "商丘市城市节点",
      "longitude": "115.1377956",
      "latitude": "34.6259779"
    },
    {
        "id": 39,
      "name": "冷水江市城市节点",
      "longitude": "111.437071",
      "latitude": "27.689902"
    },
    {
        "id": 40,
      "name": "鞍山市立山区节点",
      "longitude": "123.053",
      "latitude": "41.824"
    },
    {
        "id": 41,
      "name": "临汾市尧都区节点",
      "longitude": "111.51236",
      "latitude": "36.086536"
    },
    {
        "id": 42,
      "name": "河津市运营中心",
      "longitude": "110.42278",
      "latitude": "35.353312"
    },
    {
        "id": 43,
      "name": "北京市昌平区节点",
      "longitude": "116.336949",
      "latitude": "40.072955"
    },
    {
        "id": 44,
      "name": "台州市节点",
      "longitude": "121.414970",
      "latitude": "28.652750"
    },
    {
        "id": 45,
      "name": "链信莱芜运营中心",
      "longitude": "117.649764",
      "latitude": "36.220407"
    },
    {
        "id": 46,
      "name": "淮南市田家庵区节点",
      "longitude": "117.016973",
      "latitude": "32.647063"
    },
    {
        "id": 47,
      "name": "石家庄市桥东区城市节点",
      "longitude": "14.518677",
      "latitude": "38.073112"
    },
    {
        "id": 48,
      "name": "长沙市芙蓉区节点",
      "longitude": "113.037779",
      "latitude": "28.195841"
    },
    {
        "id": 49,
        "name": "济南市城市节点",
      "longitude": "116.897868",
      "latitude": "36.663024"
    },
    {
        "id": 50,
      "name": "东莞市市辖区城市节点",
      "longitude": "113.76288",
      "latitude": "23.0119"
    },
    {
        "id": 51,
      "name": "泉州市石狮市节点",
      "longitude": "118.631962",
      "latitude": "24.741499"
    },
    {
        "id": 52,
      "name": "江西赣州运营中心",
      "longitude": "114.931466",
      "latitude": "25.824237"
    },
    {
        "id": 53,
      "name": "呼和浩特节点",
      "longitude": "111.752918",
      "latitude": "40.813787"
    },
    {
        "id": 54,
      "name": "重庆市万州运营中心",
      "longitude": "108.409657",
      "latitude": "30.806583"
    },
    {
        "id": 55,
      "name": "咸宁市通城节点",
      "longitude": "113.823564",
      "latitude": "29.250858"
    },
    {
        "id": 56,
      "name": "上海市嘉定区节点",
      "longitude": "121.24625",
      "latitude": "31.389739"
    },
    {
        "id": 57,
      "name": "周口市川汇区节点",
      "longitude": "114.673535",
      "latitude": "33.613842"
    },
    {
        "id": 58,
      "name": "西安市城市节点",
      "longitude": "108.934593",
      "latitude": "34.339809"
    },
    {
        "id": 59,
      "name": "曲靖市麒麟区节点",
      "longitude": "103.803435",
      "latitude": "25.501726"
    },
    {
        "id": 60,
      "name": "商丘市夏邑县节点",
      "longitude": "116.139520",
      "latitude": "34.233820"
    },
    {
        "id": 61,
      "name": "烟台市莱山区城市节点",
      "longitude": "121.45249274337768",
      "latitude": "37.45805359753648"
    },
    {
        "id": 62,
      "name": "德州市德城区节点",
      "longitude": "116.154175",
      "latitude": "37.265607"
    },
    {
        "id": 63,
      "name": "衡水市城市节点",
      "longitude": "115.414005",
      "latitude": "37.7358546"
    },
    {
        "id": 64,
      "name": "中山市城市节点",
      "longitude": "113.186119",
      "latitude": "22.611240"
    },
    {
        "id": 65,
      "name": "昆明市官渡区城市节点",
      "longitude": "102.760423",
      "latitude": "24.572703"
    },
    {
        "id": 66,
      "name": "重庆市合川区节点",
      "longitude": "106.265746",
      "latitude": "30.012757"
    },
    {
        "id": 67,
      "name": "重庆市渝北节点",
      "longitude": "106.56955",
      "latitude": "29.64458"
    },
    {
        "id": 68,
      "name": "佛山顺德运营中心",
      "longitude": "113.270207",
      "latitude": "22.8145135"
    },
    {
        "id": 69,
      "name": "马鞍山市含山县节点",
      "longitude": "118.12578",
      "latitude": "31.74472"
    },
    {
        "id": 70,
      "name": "晋中市榆次区城市节点",
      "longitude": "112.727951",
      "latitude": "37.737949"
    },
    {
        "id": 71,
      "name": "南充市城市节点",
      "longitude": "106.082312",
      "latitude": "30.803524"
    },
    {
        "id": 72,
      "name": "济南市长清区节点",
      "longitude": "116.832005",
      "latitude": "36.550393"
    },
    {
        "id": 73,
      "name": "福州市长乐区节点",
      "longitude": "119.496986",
      "latitude": "25.951731"
    },
    {
        "id": 74,
      "name": "金华市城市节点",
      "longitude": "120.050159",
      "latitude": "29.284125"
    },
    {
        "id": 75,
      "name": "泉州市城市节点",
      "longitude": "118.557456",
      "latitude": "24.877293"
    },
    {
        "id": 76,
      "name": "宜宾市宜宾县节点",
      "longitude": "104.5476",
      "latitude": "28.69931"
    }
]