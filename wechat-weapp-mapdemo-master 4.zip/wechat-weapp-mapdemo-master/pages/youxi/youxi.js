Page({
  data: {
    focus: false,
    cct: '0',
    gold: '0'
  },
  cct: function (e) {
    this.setData({
      cct: e.detail.value,
    })
  },
  gold: function (e) {
    this.setData({
      gold: e.detail.value,
    })
  },
  sum: function (e) {
    var a = parseInt(this.data.cct);
    var b = parseInt(this.data.gold);
    var sumResult = a +b ;
    var numResult = (a + b) - (a + b) * 0.4;
    this.setData({
      // 把结果赋值到sum标签上
      result: sumResult,
      asResult: numResult
    })
  }
})