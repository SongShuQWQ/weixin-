Page({
  data: {
    focus: false,
    cct: '0',
    jyz: '0',
    cj: '0',
    cjcs: '0',
    zj: '0',
    zjcs: '0',
    gj: '0',
    gjcs: '0',
    zjj: '0',
    zjjcs: '0',
    ssj: '0',
    ssjcs: '0'
  },
  cct: function(e) {
    this.setData({
      cct: e.detail.value,
    })
  },
  jyz: function(e) {
    this.setData({
      jyz: e.detail.value,
    })
  },
  cj: function(e) {
    this.setData({
      cj: e.detail.value,
    })
  },
  cjcs: function(e) {
    this.setData({
      cjcs: e.detail.value,
    })
  },
  zj: function(e) {
    this.setData({
      zj: e.detail.value,
    })
  },
  zjcs: function(e) {
    this.setData({
      zjcs: e.detail.value,
    })
  },
  gj: function(e) {
    this.setData({
      gj: e.detail.value,
    })
  },
  gjcs: function(e) {
    this.setData({
      gjcs: e.detail.value,
    })
  },
  zjj: function(e) {
    this.setData({
      zjj: e.detail.value,
    })
  },
  zjjcs: function(e) {
    this.setData({
      zjjcs: e.detail.value,
    })
  },
  ssj: function(e) {
    this.setData({
      ssj: e.detail.value,
    })
  },
  ssjcs: function(e) {
    this.setData({
      ssjcs: e.detail.value,
    })
  },
  sum: function(e) {
    var a = parseInt(this.data.cct);
    var b = parseInt(this.data.jyz);
    var c = parseInt(this.data.cj);
    var d = parseInt(this.data.cjcs);
    var e = parseInt(this.data.zj);
    var f = parseInt(this.data.zjcs);
    var g = parseInt(this.data.gj);
    var h = parseInt(this.data.gjcs);
    var i = parseInt(this.data.zjj);
    var j = parseInt(this.data.zjjcs);
    var k = parseInt(this.data.ssj);
    var l = parseInt(this.data.ssjcs);
    var sumResult = a + (c * d * 0.4) + (e * f * 4.1) + (g * h * 42.6) + (i * j * 450) + (k * l * 4666.6);
      this.setData({
        // 把结果赋值到sum标签上
        result: sumResult
      })
  }
})